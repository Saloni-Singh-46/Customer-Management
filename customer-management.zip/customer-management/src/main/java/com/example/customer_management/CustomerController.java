package com.example.customer_management;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class CustomerController {

    List<Customer> customers = new ArrayList<>();
    int idCounter = 1;

    // POST - add customer
    @PostMapping("/customers")
    public Customer addCustomer(@RequestBody Customer customer) {
        customer.setId(idCounter++);
        customers.add(customer);
        return customer;
    }

    // GET - get all customers
    @GetMapping("/customers")
    public List<Customer> getCustomers() {
        return customers;
    }

    // PUT - update customer
    @PutMapping("/customers/{id}")
    public Customer updateCustomer(@PathVariable int id, @RequestBody Customer updatedCustomer) {
        for (Customer c : customers) {
            if (c.getId() == id) {
                c.setName(updatedCustomer.getName());
                c.setAddress(updatedCustomer.getAddress());
                return c;
            }
        }
        return null;
    }

    // DELETE - delete customer
    @DeleteMapping("/customers/{id}")
    public String deleteCustomer(@PathVariable int id) {
        customers.removeIf(c -> c.getId() == id);
        return "Customer deleted";
    }
}
